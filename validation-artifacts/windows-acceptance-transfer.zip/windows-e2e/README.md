# Windows installation and end-to-end acceptance

This bundle contains wheels and tests built from the current uncommitted
`feat/windows` worktree. It is prepared for execution; native Windows results
exist only after a successful run produces `result.json` with `passed: true`.
Preparing the bundle or running its non-Windows guard is not Windows validation.

Prerequisites: 64-bit Windows, CPython 3.12 or newer from python.org (x64 or
ARM64), Git for Windows on PATH, and network access to install dependencies.
No administrator privileges or global Python package installation are needed.

From PowerShell in the extracted bundle:

```powershell
.\run-windows.ps1 -Python 'C:\path\to\python.exe' -StartLocalQdrant
```

This downloads the pinned official Qdrant 1.19.2 Windows archive, verifies its
SHA256, starts it on dynamically allocated localhost ports with isolated test
data, and stops only that owned process when the run completes or fails.
Qdrant's Windows archive is x64: on Windows ARM64 it requires Windows x64
emulation. The Potpie interpreter architecture is recorded independently.
The runner does not install system runtimes if the server cannot start.

For an already provisioned test Qdrant service, use:

```powershell
.\run-windows.ps1 -Python 'C:\path\to\python.exe' -QdrantUrl 'http://127.0.0.1:6333'
```

If needed, set `CONTEXT_ENGINE_QDRANT_API_KEY` in the current shell. Keys are not
written to the manifest. Only per-test collections are modified by acceptance
tests; use a dedicated test service for this run.

Each invocation creates a new `runs/<timestamp>-<random>/` directory and fresh
virtual environment. `-Results 'C:\short path\run-1'` selects a different path;
an existing directory is rejected. Paths with spaces are supported. The runner
checks source/wheel hashes, installs both local wheels with auth and telemetry
extras, runs `pip check`, and verifies package imports come from that venv's
site-packages. The repository is never imported as the installed product.

Coverage includes actual native Ladybug persistence, rollback, multiprocess
writes, graph reliability, daemon start/restart, native Windows process APIs,
DLL bootstrap regressions, real Qdrant lifecycle/recovery, and a CLI journey
covering setup, graph recording/search, resource indexing/search, restart,
replacement, deletion and cleanup. Selected tests cannot silently skip.
The POSIX zombie assertion and ARM64 gRPC default assertion are intentionally
excluded because they are incompatible with the tested Windows installation.

The CLI journey uses deterministic local hashing embeddings. It validates the
vector service and retrieval plumbing without a paid provider; it does not
assess neural embedding relevance, browser login, or external cloud accounts.

Evidence stays under the run directory: install and dependency logs,
`installed-environment.json`, JUnit reports, `suites.json`, CLI command evidence,
`result.json`, and (when provisioned locally) Qdrant provenance/logs. Failures
retain state for diagnosis. No existing user home, installation, daemon,
repository, service, or data directory is overwritten.

Run separately with x64 and ARM64 Python, and with each supported Python
version, to claim coverage for each architecture/version combination.

"""Install bundle wheels into a fresh Windows venv and run native acceptance.

This runner does not install Python, Git, Docker, or system packages. The
optional local Qdrant mode downloads a pinned standalone server into the run.
All application/test writes use a newly created results directory. The Qdrant
service must already be reachable; its API key can be supplied through
CONTEXT_ENGINE_QDRANT_API_KEY, which is never written to the run manifest.
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import importlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import socket
import subprocess
import sys
import sysconfig
import time
import traceback
import urllib.parse
import urllib.request
import uuid
import xml.etree.ElementTree as ET
import zipfile


QDRANT_URL = "https://github.com/qdrant/qdrant/releases/download/v1.19.2/qdrant-x86_64-pc-windows-msvc.zip"
QDRANT_SHA256 = "7d86596f16c6e85d45a50312f5e16ccb51e059b62e3d7308110cb65b4c799a4d"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def run(command: list[str], *, cwd: Path, log: Path, timeout: int = 900) -> int:
    print(f"Running {log.stem}; log: {log}", flush=True)
    with log.open("w", encoding="utf-8") as output:
        completed = subprocess.run(
            command,
            cwd=cwd,
            stdout=output,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=timeout,
            check=False,
        )
    print(f"{log.stem}: exit {completed.returncode}", flush=True)
    return completed.returncode


def validate_windows() -> dict[str, object]:
    require(
        sys.platform == "win32", "Actual Windows is required; no emulation fallback"
    )
    require(sys.version_info >= (3, 12), "CPython 3.12 or newer is required")
    tag = sysconfig.get_platform().lower().replace("_", "-")
    require(tag in {"win-amd64", "win-arm64"}, f"64-bit Windows Python required: {tag}")
    return {
        "platform": sys.platform,
        "python_tag": tag,
        "machine": platform.machine(),
        "windows_version": platform.win32_ver(),
        "python": sys.version,
        "executable": sys.executable,
        "native_windows": True,
    }


def validate_qdrant(url: str) -> None:
    parsed = urllib.parse.urlsplit(url)
    require(
        parsed.scheme in {"http", "https"}
        and bool(parsed.hostname)
        and parsed.username is None
        and parsed.password is None
        and not parsed.query
        and not parsed.fragment,
        "Qdrant URL must be HTTP(S) without embedded credentials, query or fragment",
    )
    headers = {}
    if key := os.environ.get("CONTEXT_ENGINE_QDRANT_API_KEY"):
        headers["api-key"] = key
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    request = urllib.request.Request(url.rstrip("/") + "/readyz", headers=headers)
    with opener.open(request, timeout=10) as response:
        require(response.status == 200, "Qdrant readiness check failed")


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


@contextmanager
def qdrant_service(results: Path, external_url: str | None):
    if external_url:
        validate_qdrant(external_url)
        yield external_url
        return
    directory = results / "qdrant"
    directory.mkdir()
    archive = directory / "qdrant.zip"
    with urllib.request.urlopen(QDRANT_URL, timeout=120) as response:
        with archive.open("wb") as output:
            shutil.copyfileobj(response, output)
    require(
        hashlib.sha256(archive.read_bytes()).hexdigest() == QDRANT_SHA256,
        "Downloaded Qdrant archive SHA256 does not match the pinned release",
    )
    with zipfile.ZipFile(archive) as package:
        for member in package.infolist():
            target = (directory / member.filename).resolve()
            require(
                target.is_relative_to(directory.resolve()), "Unsafe Qdrant archive path"
            )
        package.extractall(directory)
    candidates = list(directory.rglob("qdrant.exe"))
    require(
        len(candidates) == 1, "Expected exactly one qdrant.exe in the release archive"
    )
    http_port, grpc_port = free_port(), free_port()
    while grpc_port == http_port:
        grpc_port = free_port()
    config = directory / "test-config.yaml"
    config.write_text(
        "log_level: INFO\ntelemetry_disabled: true\n"
        "storage:\n  storage_path: ./storage\n  snapshots_path: ./snapshots\n"
        f"service:\n  host: 127.0.0.1\n  http_port: {http_port}\n  grpc_port: {grpc_port}\n",
        encoding="utf-8",
    )
    url = f"http://127.0.0.1:{http_port}"
    manifest = {
        "version": "1.19.2",
        "architecture": "x86_64",
        "archive_sha256": QDRANT_SHA256,
        "url": url,
        "windows_machine": platform.machine(),
        "arm64_note": "On an ARM64 Windows host this x64 server requires Windows x64 emulation; Potpie uses the selected Python architecture.",
    }
    write_json(results / "qdrant-server.json", manifest)
    with (results / "qdrant-server.log").open("w", encoding="utf-8") as log:
        process = subprocess.Popen(
            [str(candidates[0]), "--config-path", str(config)],
            cwd=directory,
            stdout=log,
            stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW,
            env={
                key: value
                for key, value in os.environ.items()
                if not key.upper().startswith("QDRANT__")
            },
        )
        try:
            deadline = time.monotonic() + 45
            while True:
                require(
                    process.poll() is None, "Qdrant exited; inspect qdrant-server.log"
                )
                try:
                    validate_qdrant(url)
                    break
                except OSError:
                    if time.monotonic() >= deadline:
                        raise RuntimeError(
                            "Qdrant readiness timed out; inspect qdrant-server.log"
                        )
                    time.sleep(0.25)
            yield url
        finally:
            # The subprocess object retains our exact process handle on Windows.
            # Never look up or terminate a pre-existing Qdrant service by name/PID.
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)


def isolate_environment(results: Path, qdrant_url: str) -> None:
    keep_qdrant_key = os.environ.get("CONTEXT_ENGINE_QDRANT_API_KEY")
    for name in tuple(os.environ):
        if name.startswith(("CONTEXT_ENGINE_", "POTPIE_", "OTEL_")) or name in {
            "PYTHONPATH",
            "PYTEST_ADDOPTS",
            "LADYBUG_PATH",
            "GRAPH_DB_BACKEND",
            "FALKORDB_URL",
            "FALKORDB_LITE_PATH",
            "FALKORDB_MODE",
        }:
            os.environ.pop(name, None)
    os.environ.update(
        {
            "POTPIE_TELEMETRY_DISABLED": "1",
            "POTPIE_ENVIRONMENT": "production",
            "POTPIE_SENTRY_DSN": "",
            "POTPIE_POSTHOG_API_KEY": "",
            "POTPIE_REQUIRE_LADYBUG": "1",
            "POTPIE_REQUIRE_QDRANT": "1",
            "POTPIE_RELIABILITY_PROFILES": "ladybug",
            "CONTEXT_ENGINE_EMBEDDER": "hashing",
            "CONTEXT_ENGINE_QDRANT_URL": qdrant_url,
            "CONTEXT_ENGINE_HOME": str(results / "state"),
            "POTPIE_HARNESS_HOME": str(results / "harness"),
            "XDG_CONFIG_HOME": str(results / "config"),
            "PYTHON_KEYRING_BACKEND": "keyring.backends.null.Keyring",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONUTF8": "1",
        }
    )
    if keep_qdrant_key:
        os.environ["CONTEXT_ENGINE_QDRANT_API_KEY"] = keep_qdrant_key


def verify_installed(results: Path) -> dict[str, object]:
    details = validate_windows()
    require(Path(sys.prefix).resolve() == (results / "venv").resolve(), "Wrong venv")
    sites = {Path(sysconfig.get_path(key)).resolve() for key in ("purelib", "platlib")}
    origins = {}
    for name in ("potpie", "potpie_context_engine"):
        origin = Path(importlib.import_module(name).__file__).resolve()
        require(
            any(origin.is_relative_to(site) for site in sites),
            f"Source import: {origin}",
        )
        origins[name] = str(origin)
    require(
        importlib.util.find_spec("sqlite_vec") is None,
        "sqlite-vec unexpectedly installed",
    )
    require(
        importlib.util.find_spec("qdrant_client") is None,
        "Qdrant SDK unexpectedly installed",
    )
    require(
        importlib.util.find_spec("ladybug") is not None,
        "Native Ladybug package missing",
    )
    require(
        importlib.util.find_spec("opentelemetry.exporter.otlp.proto.http") is not None,
        "HTTP telemetry exporter missing",
    )
    if details["python_tag"] == "win-arm64":
        require(
            importlib.util.find_spec("grpc") is None,
            "ARM64 install unexpectedly includes grpcio",
        )
    details["origins"] = origins
    details["packages"] = sorted(
        (
            {"name": d.metadata["Name"], "version": d.version}
            for d in importlib.metadata.distributions()
        ),
        key=lambda item: str(item["name"]).lower(),
    )
    write_json(results / "installed-environment.json", details)
    return details


def run_suite(
    work: Path, results: Path, name: str, selections: list[str]
) -> dict[str, object]:
    report = results / f"{name}.xml"
    code = run(
        [
            sys.executable,
            "-m",
            "pytest",
            "-q",
            "--tb=short",
            "--import-mode=importlib",
            "-p",
            "no:cacheprovider",
            f"--junitxml={report}",
            *selections,
        ],
        cwd=work,
        log=results / f"{name}.log",
        timeout=1200,
    )
    cases = ET.parse(report).getroot().findall(".//testcase") if report.exists() else []
    skipped = [case.get("name") for case in cases if case.find("skipped") is not None]
    return {
        "suite": name,
        "exit_code": code,
        "tests": len(cases),
        "skipped": skipped,
        "passed": code == 0 and bool(cases) and not skipped,
    }


def installed_phase(bundle: Path, results: Path, qdrant_url: str) -> bool:
    isolate_environment(results, qdrant_url)
    details = verify_installed(results)
    source = bundle / "source"
    work = results / "acceptance"
    work.mkdir()
    for name, path in (("root", source), ("engine", source / "potpie/context-engine")):
        destination = work / name
        shutil.copytree(
            path / "tests",
            destination / "tests",
            ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache"),
        )
        (destination / "pytest.ini").write_text(
            "[pytest]\nasyncio_mode = auto\nmarkers =\n"
            "    integration: native acceptance\n    unit: platform regression\n",
            encoding="utf-8",
        )
    suites = []
    selections = [
        (
            "engine",
            "ladybug",
            [
                "tests/integration/test_ladybug_roundtrip.py",
                "tests/conformance/test_graph_reliability.py",
            ],
        ),
        (
            "engine",
            "qdrant",
            [
                "tests/integration/test_qdrant_resource_index.py",
                "tests/unit/test_qdrant_http.py",
                "tests/unit/test_qdrant_resource_sync.py",
            ],
        ),
        (
            "engine",
            "native-loading",
            [
                "tests/unit/test_ladybug_windows_bootstrap.py",
                "tests/unit/test_settings_graph_backend.py",
            ],
        ),
        ("root", "daemon", ["tests/integration/test_ladybug_runtime.py"]),
        (
            "root",
            "windows-processes",
            [
                "tests/unit/test_daemon_spawn.py",
                "tests/unit/test_daemon_liveness.py",
                "tests/unit/test_ladybug_registry.py",
                "-k",
                "not test_an_exited_unreaped_child_is_not_alive",
            ],
        ),
    ]
    telemetry = ["tests/unit/test_otel_transport.py"]
    if details["python_tag"] == "win-arm64":
        telemetry += ["-k", "not other_platforms_keep_grpc_port_4317"]
    selections.append(("engine", "telemetry", telemetry))
    for directory, name, tests in selections:
        try:
            result = run_suite(work / directory, results, name, tests)
        except Exception as exc:
            result = {"suite": name, "passed": False, "error": str(exc)}
        suites.append(result)
        write_json(results / "suites.json", suites)
    cli_code = run(
        [
            sys.executable,
            "-I",
            str(bundle / "run_windows_e2e.py"),
            "--qdrant-url",
            qdrant_url,
            "--results",
            str(results / "cli"),
            "--potpie",
            str(Path(sys.executable).with_name("potpie.exe")),
        ],
        cwd=work,
        log=results / "cli-e2e.log",
        timeout=1200,
    )
    passed = all(suite["passed"] for suite in suites) and cli_code == 0
    write_json(
        results / "result.json",
        {
            "native_windows": True,
            "passed": passed,
            "suites": suites,
            "cli_exit_code": cli_code,
            "environment": "installed-environment.json",
            "excluded": ["POSIX-only unreaped zombie process assertion"]
            + (
                [
                    "gRPC default assertion on ARM64: installation intentionally uses HTTP"
                ]
                if details["python_tag"] == "win-arm64"
                else []
            ),
        },
    )
    return passed


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    service = parser.add_mutually_exclusive_group(required=True)
    service.add_argument("--qdrant-url")
    service.add_argument("--start-local-qdrant", action="store_true")
    parser.add_argument("--results", type=Path)
    parser.add_argument(
        "--installed-phase", action="store_true", help=argparse.SUPPRESS
    )
    args = parser.parse_args()
    machine = validate_windows()
    bundle = Path(__file__).resolve().parent
    if args.installed_phase:
        require(args.results is not None, "Installed phase needs a results directory")
        require(
            args.qdrant_url is not None,
            "Installed phase requires the provisioned Qdrant URL",
        )
        validate_qdrant(args.qdrant_url)
        raise SystemExit(
            0 if installed_phase(bundle, args.results.resolve(), args.qdrant_url) else 1
        )
    require(
        shutil.which("git") is not None,
        "Git for Windows is required for the CLI setup journey",
    )
    wheels = sorted((bundle / "dist").glob("*.whl"))
    root_wheels = [path for path in wheels if path.name.startswith("potpie-")]
    engine_wheels = [
        path for path in wheels if path.name.startswith("potpie_context_engine-")
    ]
    require(
        len(root_wheels) == len(engine_wheels) == 1,
        "Bundle needs exactly one CLI and one engine wheel",
    )
    require((bundle / "source/tests").is_dir(), "Bundle source/tests missing")
    require((bundle / "run_windows_e2e.py").is_file(), "CLI E2E harness missing")
    manifest = json.loads((bundle / "wheel-manifest.json").read_text(encoding="utf-8"))
    require(
        set(manifest) == {path.name for path in wheels},
        "Wheel manifest does not match bundle wheels",
    )
    for wheel in wheels:
        require(
            hashlib.sha256(wheel.read_bytes()).hexdigest()
            == manifest[wheel.name]["sha256"],
            f"Wheel hash mismatch: {wheel.name}",
        )
    source_manifest = json.loads(
        (bundle / "source-manifest.json").read_text(encoding="utf-8")
    )
    for name, digest in source_manifest["source_files"].items():
        path = (bundle / "source" / name).resolve()
        require(
            path.is_relative_to((bundle / "source").resolve()),
            "Unsafe source manifest path",
        )
        require(
            path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == digest,
            f"Source hash mismatch: {name}",
        )
    results = (
        args.results
        or bundle
        / "runs"
        / (time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:8])
    ).resolve()
    require(
        not results.exists(), f"Refusing to reuse existing results directory: {results}"
    )
    results.mkdir(parents=True)
    print(f"Results: {results}", flush=True)
    with qdrant_service(results, args.qdrant_url) as qdrant_url:
        write_json(
            results / "installation-manifest.json",
            {
                "bootstrap": machine,
                "wheels": manifest,
                "qdrant_url": qdrant_url,
                "source_head": source_manifest["head"],
                "source_includes_uncommitted_changes": source_manifest[
                    "includes_uncommitted_changes"
                ],
                "source_manifest_sha256": hashlib.sha256(
                    (bundle / "source-manifest.json").read_bytes()
                ).hexdigest(),
            },
        )
        os.environ.pop("PYTHONPATH", None)
        require(
            run(
                [sys.executable, "-I", "-m", "venv", str(results / "venv")],
                cwd=results,
                log=results / "venv.log",
            )
            == 0,
            "Venv creation failed",
        )
        python = results / "venv/Scripts/python.exe"
        command = [
            str(python),
            "-I",
            "-m",
            "pip",
            "install",
            "--disable-pip-version-check",
            str(root_wheels[0]) + "[auth,telemetry]",
            str(engine_wheels[0]),
            "pytest",
            "pytest-asyncio",
        ]
        require(
            run(command, cwd=results, log=results / "install.log", timeout=1800) == 0,
            "Product installation failed; inspect install.log",
        )
        require(
            run(
                [str(python), "-I", "-m", "pip", "check"],
                cwd=results,
                log=results / "pip-check.log",
            )
            == 0,
            "Dependency consistency check failed",
        )
        code = run(
            [
                str(python),
                "-I",
                str(Path(__file__).resolve()),
                "--installed-phase",
                "--results",
                str(results),
                "--qdrant-url",
                qdrant_url,
            ],
            cwd=results,
            log=results / "acceptance.log",
            timeout=7200,
        )
    print(
        f"Windows acceptance {'PASSED' if code == 0 else 'FAILED'}; evidence: {results}"
    )
    raise SystemExit(code)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise SystemExit(1)

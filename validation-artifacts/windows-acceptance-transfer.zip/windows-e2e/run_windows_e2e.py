"""Exercise an installed Potpie CLI against native Windows and a live Qdrant.

Run using the fresh installation's Python, with -I. No checkout is imported.
The result directory must be new. Test data, command output, and diagnostics are
retained there. Only the test's daemon and Qdrant collection are cleaned up.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import sqlite3
import subprocess
import sys
import sysconfig
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import uuid


def require(condition: object, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def save(path: Path, value: object) -> None:
    path.write_text(
        json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )


def payloads(result: dict) -> list[dict]:
    return [item.get("payload", {}) for item in result.get("items", [])]


class Journey:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.root = args.results.resolve()
        self.root.mkdir(parents=True, exist_ok=False)
        self.commands = self.root / "commands"
        self.commands.mkdir()
        self.work = self.root / "working directory with spaces"
        self.work.mkdir()
        self.home = self.root / "potpie state"
        self.home.mkdir()
        self.report: dict = {
            "started_at": dt.datetime.now(dt.timezone.utc).isoformat(),
            "status": "running",
            "native_windows": sys.platform == "win32",
            "validation_only": args.validation_only,
            "platform": platform.platform(),
            "machine": platform.machine(),
            "python": sys.version,
            "python_executable": sys.executable,
            "python_platform": sysconfig.get_platform(),
            "steps": [],
            "scope": "Installed CLI, Ladybug graph, detached daemon, SQLite resources, live Qdrant HTTP, restart persistence and deletion",
            "not_covered": [
                "Interactive setup prompts and browser UI rendering",
                "Cloud authentication, external integrations and real credentials",
                "SentenceTransformer installation or neural semantic relevance",
                "Machine reboot or service auto-start",
            ],
        }
        self.collection: str | None = None
        self.namespace: str | None = None
        self.pot = ""
        self.daemon_attempted = False
        self.index = 0
        self.url = args.qdrant_url.rstrip("/")
        parts = urllib.parse.urlsplit(self.url)
        require(
            parts.scheme in {"http", "https"} and parts.hostname,
            "A real HTTP(S) Qdrant URL is required",
        )
        require(
            not parts.username
            and not parts.password
            and not parts.query
            and not parts.fragment,
            "Pass Qdrant credentials through CONTEXT_ENGINE_QDRANT_API_KEY, not the URL",
        )
        self.report["qdrant_url"] = self.url
        self.key = os.environ.get("CONTEXT_ENGINE_QDRANT_API_KEY", "")
        allowed = {
            "PATH",
            "PATHEXT",
            "SYSTEMROOT",
            "WINDIR",
            "COMSPEC",
            "SYSTEMDRIVE",
            "TEMP",
            "TMP",
            "LANG",
            "LC_ALL",
            "TZ",
            "NUMBER_OF_PROCESSORS",
            "PROCESSOR_ARCHITECTURE",
            "PROCESSOR_IDENTIFIER",
            "OS",
            "SSL_CERT_FILE",
            "SSL_CERT_DIR",
            "REQUESTS_CA_BUNDLE",
            "USERPROFILE",
            "HOMEDRIVE",
            "HOMEPATH",
        }
        self.env = {
            key: value for key, value in os.environ.items() if key.upper() in allowed
        }
        self.cli = (
            args.potpie.resolve()
            if args.potpie
            else Path(sys.executable).parent
            / ("potpie.exe" if sys.platform == "win32" else "potpie")
        )
        require(self.cli.is_file(), f"Installed CLI not found: {self.cli}")
        require(
            self.cli.parent == Path(sys.executable).parent.resolve(),
            "The CLI and Python must belong to the same isolated installation",
        )
        self.env.update(
            {
                "PATH": str(self.cli.parent) + os.pathsep + self.env.get("PATH", ""),
                "CONTEXT_ENGINE_HOME": str(self.home),
                "POTPIE_HARNESS_HOME": str(self.root / "harness"),
                "XDG_CONFIG_HOME": str(self.root / "config"),
                "APPDATA": str(self.root / "appdata"),
                "LOCALAPPDATA": str(self.root / "localappdata"),
                "CONTEXT_ENGINE_HOST_MODE": "daemon",
                "CONTEXT_ENGINE_EMBEDDER": "hashing",
                "CONTEXT_ENGINE_QDRANT_URL": self.url,
                "POTPIE_TELEMETRY_DISABLED": "1",
                "POTPIE_ENVIRONMENT": "production",
                "PYTHON_KEYRING_BACKEND": "keyring.backends.null.Keyring",
                "PYTHONUTF8": "1",
                "NO_COLOR": "1",
                "_TYPER_FORCE_DISABLE_TERMINAL": "1",
            }
        )
        if self.key:
            self.env["CONTEXT_ENGINE_QDRANT_API_KEY"] = self.key
        if sys.platform != "win32":
            self.env["CONTEXT_ENGINE_BACKEND"] = "ladybug"
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def step(self, name: str, detail: object = None) -> None:
        self.report["steps"].append({"name": name, "passed": True, "detail": detail})
        save(self.root / "result.json", self.report)
        print(f"PASS {name}", flush=True)

    def command(
        self, *args: str, allowed_codes: tuple[int, ...] = (0,), timeout: int = 90
    ) -> dict:
        self.index += 1
        command = [str(self.cli), "--json", "--host", "local", *args]
        started = time.monotonic()
        output = subprocess.run(
            command,
            cwd=self.work,
            env=self.env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
        )
        evidence = {
            "command": command,
            "returncode": output.returncode,
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "stdout": output.stdout,
            "stderr": output.stderr,
        }
        save(self.commands / f"{self.index:03d}-{args[0]}.json", evidence)
        require(
            output.returncode in allowed_codes,
            f"CLI failed ({output.returncode}): {' '.join(args)}; see command {self.index:03d}",
        )
        try:
            body = json.loads(output.stdout)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                f"CLI did not return JSON: command {self.index:03d}"
            ) from exc
        require(isinstance(body, dict), "Expected a JSON object from CLI")
        return body

    def qdrant(self, method: str, path: str, data: dict | None = None) -> dict:
        headers = {"Content-Type": "application/json"}
        if self.key:
            headers["api-key"] = self.key
        request = urllib.request.Request(
            self.url + path,
            data=None if data is None else json.dumps(data).encode(),
            headers=headers,
            method=method,
        )
        with self.opener.open(request, timeout=15) as response:
            content = response.read()
            return json.loads(content) if content else {}

    def identify_collection(self, location: str) -> None:
        database = Path(location).resolve()
        require(
            database.is_relative_to(self.home),
            "Resource database escaped isolated test home",
        )
        with sqlite3.connect(
            database.as_uri() + "?mode=ro", uri=True, timeout=10
        ) as connection:
            metadata = dict(
                connection.execute(
                    "SELECT key,value FROM meta WHERE key IN ('qdrant_namespace','embedder','dimensions')"
                )
            )
        namespace = metadata["qdrant_namespace"]
        require(
            len(namespace) == 32 and all(ch in "0123456789abcdef" for ch in namespace),
            "Invalid private Qdrant namespace",
        )
        digest = hashlib.sha256(
            f"{metadata['embedder']}\0{metadata['dimensions']}".encode()
        ).hexdigest()[:16]
        self.namespace = namespace
        self.collection = f"potpie_resources_{namespace}_{digest}"
        self.report["qdrant_collection"] = self.collection
        self.report["resource_database"] = str(database)

    def points(self) -> int:
        require(
            self.collection and self.namespace and self.pot,
            "Qdrant test scope is not established",
        )
        result = self.qdrant(
            "POST",
            f"/collections/{self.collection}/points/count",
            {
                "exact": True,
                "filter": {
                    "must": [
                        {"key": "namespace", "match": {"value": self.namespace}},
                        {"key": "pot_id", "match": {"value": self.pot}},
                        {"key": "doc", "match": {"value": "windows-fixture"}},
                    ]
                },
            },
        )
        return int(result["result"]["count"])

    def drain(self) -> dict:
        for _ in range(12):
            result = self.command(
                "resource", "index", "build", "--wait", "--pot", self.pot
            )
            if result.get("remaining") == 0 and not result.get("detail"):
                return result
            time.sleep(0.5)
        raise RuntimeError(f"Qdrant indexing failed to drain: {result}")

    def write_fixture(self, text: str) -> Path:
        directory = self.root / "import fixture with spaces"
        (directory / "body").mkdir(parents=True, exist_ok=True)
        (directory / "body" / "0000.txt").write_text(text, encoding="utf-8")
        save(
            directory / "meta.json",
            {
                "source_ref": "file:///windows-e2e-fixture.txt",
                "source_kind": "text",
                "sections": [
                    {
                        "slug": "body",
                        "title": "Windows installation fixture",
                        "ordinal": 0,
                        "summary": "A test fixture for installed resource search and persistence.",
                        "content_hash": hashlib.sha256(text.encode()).hexdigest(),
                        "chunks": [{"seq": 0, "label": "Windows fixture"}],
                    }
                ],
            },
        )
        return directory

    def search_resource(self, query: str) -> dict:
        return self.command(
            "search", query, "--include", "resources", "--pot", self.pot
        )

    def assert_resource(self, query: str, text: str) -> None:
        result = self.search_resource(query)
        matching = [
            row
            for row in payloads(result)
            if row.get("kind") == "resource_chunk"
            and row.get("doc") == "windows-fixture"
        ]
        require(matching, "Resource search returned no fixture chunk")
        require(
            any(
                row.get("retrieval", {}).get("match_mode") == "hybrid"
                and row.get("retrieval", {}).get("semantic_rank") is not None
                for row in matching
            ),
            "Search did not report a real Qdrant vector contribution",
        )
        fetched = self.command(
            "resource",
            "get",
            matching[0]["resource_id"],
            "--full",
            "--pot",
            self.pot,
        )
        require(
            fetched.get("count") == 1 and fetched["chunks"][0]["text"] == text,
            "Resource fetch did not return exact UTF-8 text",
        )

    def execute(self) -> None:
        require(
            sys.platform == "win32" or self.args.validation_only,
            "Native Windows is required; --validation-only is exclusively for harness validation on another OS",
        )
        require(
            sys.prefix != sys.base_prefix,
            "Use the fresh installation's virtual-environment Python",
        )
        probe = """import importlib,importlib.metadata as m,json,pathlib,sysconfig
sites={pathlib.Path(sysconfig.get_path(n)).resolve() for n in ('purelib','platlib')}
origins={}
for name in ('potpie','potpie_context_engine','ladybug'):
 p=pathlib.Path(importlib.import_module(name).__file__).resolve()
 assert any(p.is_relative_to(s) for s in sites),str(p)
 origins[name]=str(p)
print(json.dumps({'origins':origins,'versions':{n:m.version(n) for n in ('potpie','potpie-context-engine','ladybug')}}))
"""
        output = subprocess.run(
            [sys.executable, "-I", "-c", probe],
            cwd=self.work,
            env=self.env,
            capture_output=True,
            text=True,
            timeout=60,
        )
        save(
            self.root / "installation-probe.json",
            {
                "returncode": output.returncode,
                "stdout": output.stdout,
                "stderr": output.stderr,
            },
        )
        require(output.returncode == 0, "Installed-package origin probe failed")
        self.step("installed wheel imports", json.loads(output.stdout))
        self.qdrant("GET", "/collections")
        self.step("live Qdrant available")
        config = self.command("config", "list")
        self.step("fresh CLI configuration", config)
        self.daemon_attempted = True
        setup = self.command(
            "setup",
            "--yes",
            "--daemon",
            "--embeddings",
            "local",
            "--repo",
            str(self.work),
            "--pot",
            "windows-e2e",
            "--agent",
            "codex",
            timeout=180,
        )
        require(setup.get("ok") is True, "First-run setup reported failure")
        daemon = self.command("daemon", "status")
        require(daemon.get("up") and daemon.get("ready"), "Daemon is not ready")
        self.step("first-run setup and detached daemon", daemon)
        doctor = self.command("doctor")
        require(
            doctor.get("backend_profile") == "ladybug"
            and doctor.get("backend_ready") is True,
            "Windows default backend is not ready Ladybug",
        )
        self.step("default Ladybug backend ready")
        pot = self.command("pot", "create", "windows-e2e-second", "--use")
        self.pot = pot["id"]
        require(
            pot.get("created") is True and pot.get("active") is True,
            "New pot was not created and selected",
        )
        self.step("pot creation", {"id": self.pot})
        nonce = uuid.uuid4().hex[:12]
        graph_text = f"Windows durable graph acceptance {nonce}"
        recorded = self.command(
            "record",
            "--type",
            "feature_note",
            "--summary",
            graph_text,
            "--scope",
            "service:windows-e2e",
            "--pot",
            self.pot,
        )
        require(
            recorded.get("accepted") and recorded.get("mutations_applied", 0) > 0,
            "Graph record was not committed",
        )
        searched = self.command(
            "search", graph_text, "--include", "raw_graph", "--pot", self.pot
        )
        require(
            any(row.get("fact") == graph_text for row in payloads(searched)),
            "Graph record could not be queried",
        )
        self.step("graph write and search")
        initial = f"Cobalt {nonce} quota recovery works on Windows. UTF-8 café 東京.\n"
        directory = self.write_fixture(initial)
        imported = self.command(
            "resource",
            "import",
            str(directory),
            "--doc",
            "windows-fixture",
            "--pot",
            self.pot,
        )
        require(
            imported.get("ok") is True and imported.get("chunk_count") == 1,
            "Resource import failed",
        )
        self.drain()
        status = self.command("resource", "index", "status", "--pot", self.pot)
        require(
            status.get("profile") == "qdrant_hybrid"
            and status.get("match_mode") == "hybrid"
            and status.get("pending_embeddings") == 0,
            "Default Qdrant index is not hybrid and fully drained",
        )
        self.identify_collection(status["location"])
        require(self.points() > 0, "No actual points reached Qdrant")
        self.assert_resource(f"Cobalt {nonce} quota", initial)
        self.step(
            "resource import, real vector storage, hybrid search and UTF-8 fetch",
            {"points": self.points()},
        )
        self.command("daemon", "restart")
        restarted = self.command("daemon", "status")
        require(
            restarted.get("up") and restarted.get("ready"), "Daemon did not restart"
        )
        require(
            restarted.get("pid") != daemon.get("pid"),
            "Restart did not replace the detached daemon process",
        )
        searched = self.command(
            "search", graph_text, "--include", "raw_graph", "--pot", self.pot
        )
        require(
            any(row.get("fact") == graph_text for row in payloads(searched)),
            "Graph record was lost after restart",
        )
        self.assert_resource(f"Cobalt {nonce} quota", initial)
        self.step("graph and resource persistence after daemon restart")
        replacement = f"Amber {nonce} replacement survives clean installation. UTF-8 naïve résumé.\n"
        self.write_fixture(replacement)
        imported_again = self.command(
            "resource",
            "import",
            str(directory),
            "--doc",
            "windows-fixture",
            "--pot",
            self.pot,
        )
        require(
            imported_again.get("revision", 0) > imported.get("revision", 0),
            "Resource revision did not advance",
        )
        self.drain()
        ambiguous = self.command(
            "resource",
            "get",
            "potpie://res/windows-fixture/body/0000",
            "--pot",
            self.pot,
            allowed_codes=(1,),
        )
        require(
            ambiguous.get("code") == "resource_revision_ambiguous",
            "An unversioned resource did not expose the revised-document ambiguity",
        )
        self.assert_resource(f"Amber {nonce} replacement", replacement)
        old_search = self.search_resource(f"Cobalt {nonce} quota")
        require(
            all("Cobalt" not in row.get("snippet", "") for row in payloads(old_search)),
            "Replacement search returned old resource text",
        )
        self.step("resource replacement removes stale text")
        removed = self.command(
            "resource", "rm", "windows-fixture", "--confirm", "--pot", self.pot
        )
        require(removed.get("removed") is True, "Resource deletion failed")
        self.drain()
        require(self.points() == 0, "Deleted resource still has Qdrant vectors")
        require(
            not payloads(self.search_resource(f"Amber {nonce} replacement")),
            "Deleted resource remains searchable",
        )
        self.command("daemon", "restart")
        require(
            not payloads(self.search_resource(f"Amber {nonce} replacement")),
            "Deleted resource returned after restart",
        )
        self.step(
            "resource deletion is durable with no stale vectors or search results"
        )
        require(
            (self.home / "context_graph" / "ladybug.db").is_file(),
            "Ladybug database was not persisted",
        )

    def cleanup(self) -> None:
        failures = []
        if self.daemon_attempted:
            try:
                self.command("daemon", "logs", "--tail", "300", allowed_codes=(0, 2, 3))
            except Exception as exc:
                self.report["diagnostic_log_error"] = str(exc)
            try:
                self.command("daemon", "stop")
                stopped = self.command("daemon", "status", allowed_codes=(2,))
                require(not stopped.get("up"), "Test daemon remains running after stop")
                self.step("daemon stopped and unavailable")
            except Exception as exc:
                failures.append(f"daemon cleanup: {exc}")
        if not self.collection:
            database = self.home / "index" / "resources.sqlite3"
            if database.is_file():
                try:
                    self.identify_collection(str(database))
                except Exception as exc:
                    self.report["collection_identification_error"] = str(exc)
        if self.collection:
            try:
                self.qdrant("DELETE", f"/collections/{self.collection}")
                self.step("test-owned Qdrant collection removed")
            except urllib.error.HTTPError as exc:
                if exc.code != 404:
                    failures.append(f"Qdrant cleanup: HTTP {exc.code}")
            except Exception as exc:
                failures.append(f"Qdrant cleanup: {exc}")
        if failures:
            self.report["cleanup_errors"] = failures
            raise RuntimeError("; ".join(failures))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--qdrant-url", required=True)
    parser.add_argument("--results", required=True, type=Path)
    parser.add_argument("--potpie", type=Path)
    parser.add_argument(
        "--validation-only",
        action="store_true",
        help="Permit non-Windows exclusively to validate this test harness; result is explicitly not Windows acceptance",
    )
    args = parser.parse_args()
    journey = Journey(args)
    try:
        journey.execute()
    except Exception:
        journey.report["failure"] = traceback.format_exc()
        journey.report["status"] = "failed"
    else:
        journey.report["status"] = (
            "validation_passed" if args.validation_only else "passed"
        )
    finally:
        try:
            journey.cleanup()
        except Exception:
            journey.report["cleanup_failure"] = traceback.format_exc()
            journey.report["status"] = "failed"
        journey.report["finished_at"] = dt.datetime.now(dt.timezone.utc).isoformat()
        save(journey.root / "result.json", journey.report)
    print(
        json.dumps(
            {
                "status": journey.report["status"],
                "native_windows": journey.report["native_windows"],
                "results": str(journey.root),
            }
        ),
        flush=True,
    )
    if journey.report["status"] == "failed":
        print(
            journey.report.get(
                "failure", journey.report.get("cleanup_failure", "Failed")
            ),
            file=sys.stderr,
        )
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from types import ModuleType
from typing import Any

import pytest

from potpie.cli.telemetry import sentry_runtime
from potpie_context_engine.bootstrap import sentry_metrics_runtime
from potpie.cli.telemetry.context import TelemetryContext
from potpie.cli.telemetry.sentry_runtime import (
    capture_unexpected_cli_error,
    configure_cli_sentry,
)
from potpie.cli.telemetry.settings import SentrySettings


@dataclass
class _Scope:
    tags: dict[str, str] = field(default_factory=dict)
    contexts: dict[str, dict[str, str]] = field(default_factory=dict)

    def __enter__(self) -> "_Scope":
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        return None

    def set_tag(self, key: str, value: str) -> None:
        self.tags[key] = value

    def set_context(self, key: str, value: dict[str, str]) -> None:
        self.contexts[key] = value


class _FakeSentry(ModuleType):
    def __init__(self) -> None:
        super().__init__("sentry_sdk")
        self.init_calls: list[dict[str, object]] = []
        self.captured: list[BaseException] = []
        self.scope = _Scope()

    def init(self, **kwargs: Any) -> None:
        self.init_calls.append(dict(kwargs))

    def new_scope(self) -> _Scope:
        self.scope = _Scope()
        return self.scope

    def capture_exception(self, exc: BaseException) -> None:
        self.captured.append(exc)


@pytest.fixture(autouse=True)
def reset_sentry_runtime(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(sentry_runtime, "_configured", False)
    monkeypatch.setattr(sentry_runtime, "_settings", None)
    monkeypatch.setattr(sentry_metrics_runtime, "_configured", False)
    monkeypatch.setattr(sentry_metrics_runtime, "_enabled", False)
    monkeypatch.setattr(sentry_metrics_runtime, "_sentry_sdk", None)
    sentry_metrics_runtime.set_metric_recorder(None)


def _settings(*, enabled: bool = True) -> SentrySettings:
    return SentrySettings(
        enabled=enabled,
        dsn="https://public@example.invalid/1",
        environment="staging",
        release="potpie-cli@test",
        dist="cli-dist",
    )


def test_configure_cli_sentry_initialises_nothing_and_routes_metrics_to_the_spool(
    monkeypatch,
) -> None:
    """The SDK used to be initialised on every command right here; that init
    (forty integration probes) and its envelope at exit were most of what
    telemetry cost. Now configuring arms crash capture and installs the spool
    recorder, and ``sentry_sdk`` stays unimported until an error needs it."""
    fake = _FakeSentry()
    monkeypatch.setitem(sys.modules, "sentry_sdk", fake)
    spooled: list[dict[str, object]] = []
    monkeypatch.setattr("potpie.cli.telemetry.spool.append", spooled.append)

    configure_cli_sentry(_settings())
    sentry_metrics_runtime.count(
        "ce.cli.invocations_total", attributes={"result": "ok", "path": "/etc/x"}
    )

    assert fake.init_calls == []
    assert sentry_metrics_runtime.metrics_configured() is False
    assert sentry_runtime._configured is True
    assert sentry_metrics_runtime.metric_recorder() is sentry_runtime.spool_metric
    assert spooled == [
        {
            "kind": "metric",
            "type": "count",
            "name": "ce.cli.invocations_total",
            "value": 1,
            "unit": None,
            # The allowlist ran before the sink saw the attributes.
            "attributes": {"result": "ok"},
        }
    ]


def test_first_unexpected_error_initialises_the_sdk_with_privacy_hooks(
    monkeypatch,
) -> None:
    fake = _FakeSentry()
    monkeypatch.setitem(sys.modules, "sentry_sdk", fake)
    configure_cli_sentry(_settings())
    exc = RuntimeError("boom")

    capture_unexpected_cli_error(
        exc, error_code="unexpected_cli_error", error_kind="unexpected"
    )
    capture_unexpected_cli_error(
        exc, error_code="unexpected_cli_error", error_kind="unexpected"
    )

    assert len(fake.init_calls) == 1
    call = fake.init_calls[0]
    assert call["dsn"] == "https://public@example.invalid/1"
    assert call["send_default_pii"] is False
    assert call["include_local_variables"] is False
    assert call["max_request_body_size"] == "never"
    assert callable(call["before_send"])
    assert callable(call["before_breadcrumb"])
    # The CLI profile, since this process is about to exit.
    assert call["auto_enabling_integrations"] is False
    assert call["shutdown_timeout"] == 1.0
    assert fake.captured == [exc, exc]


def test_configure_cli_sentry_disabled_does_not_import(monkeypatch) -> None:
    monkeypatch.delitem(sys.modules, "sentry_sdk", raising=False)
    settings = SentrySettings(
        enabled=False,
        dsn="https://public@example.invalid/1",
        environment="dev",
        release="potpie-cli@test",
        dist=None,
    )

    configure_cli_sentry(settings)

    assert "sentry_sdk" not in sys.modules


def test_configure_cli_sentry_disabled_disarms_capture_and_removes_the_recorder(
    monkeypatch,
) -> None:
    fake = _FakeSentry()
    monkeypatch.setitem(sys.modules, "sentry_sdk", fake)

    configure_cli_sentry(_settings(enabled=True))
    configure_cli_sentry(_settings(enabled=False))
    capture_unexpected_cli_error(
        RuntimeError("boom"),
        error_code="unexpected_cli_error",
        error_kind="unexpected",
    )

    assert sentry_runtime._configured is False
    assert sentry_metrics_runtime.metric_recorder() is None
    assert fake.init_calls == []
    assert fake.captured == []


def test_capture_unexpected_cli_error_sets_allowlisted_scope(monkeypatch) -> None:
    fake = _FakeSentry()
    monkeypatch.setitem(sys.modules, "sentry_sdk", fake)
    configure_cli_sentry(_settings())
    telemetry = TelemetryContext(
        anonymous_install_id="install_123",
        invocation_id="invoke_456",
        daemon_session_id="daemon_789",
        environment="staging",
        command="daemon",
        subcommand="status",
        output_mode="json",
        cli_version="0.1.0",
        python_version="3.13.0",
        os="darwin",
        arch="arm64",
    )
    monkeypatch.setattr(
        "potpie.cli.telemetry.sentry_runtime.current_telemetry_context",
        lambda: telemetry,
    )

    exc = RuntimeError("boom")
    capture_unexpected_cli_error(
        exc,
        error_code="unexpected_cli_error",
        error_kind="unexpected",
    )

    assert fake.captured == [exc]
    assert fake.scope.tags == {
        "arch": "arm64",
        "cli_version": "0.1.0",
        "command": "daemon",
        "error.code": "unexpected_cli_error",
        "error.kind": "unexpected",
        "is_expected": "false",
        "os": "darwin",
        "output_mode": "json",
        "python_version": "3.13.0",
        "service": "potpie-cli",
        "subcommand": "status",
    }
    assert fake.scope.contexts["telemetry"] == {
        "anonymous_install_id": "install_123",
        "daemon_session_id": "daemon_789",
        "invocation_id": "invoke_456",
    }


def test_capture_unexpected_cli_error_skips_when_not_configured(monkeypatch) -> None:
    fake = _FakeSentry()
    monkeypatch.setitem(sys.modules, "sentry_sdk", fake)

    capture_unexpected_cli_error(
        RuntimeError("boom"),
        error_code="unexpected_cli_error",
        error_kind="unexpected",
    )

    assert fake.captured == []


def test_capture_unexpected_cli_error_is_nonfatal_without_sentry(monkeypatch) -> None:
    monkeypatch.delitem(sys.modules, "sentry_sdk", raising=False)
    monkeypatch.setattr(sentry_runtime, "_configured", True)

    capture_unexpected_cli_error(
        RuntimeError("boom"),
        error_code="unexpected_cli_error",
        error_kind="unexpected",
    )

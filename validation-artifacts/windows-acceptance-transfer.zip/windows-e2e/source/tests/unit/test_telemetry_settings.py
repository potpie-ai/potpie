from __future__ import annotations

import pytest

from potpie.cli.telemetry.preferences import (
    TelemetryPreferences,
    save_preferences,
)
from potpie.cli.telemetry.settings import (
    load_telemetry_resolution,
    load_sentry_settings as load_cli_sentry_settings,
    telemetry_environment as cli_telemetry_environment,
)
from potpie.runtime import sentry_settings as shared_sentry_settings
from potpie.runtime import settings as runtime_settings

_SENTRY_ENV_NAMES = (
    "POTPIE_ENVIRONMENT",
    "POTPIE_TELEMETRY_DISABLED",
    "POTPIE_SENTRY_ENABLED",
    "POTPIE_SENTRY_DSN",
    "POTPIE_SENTRY_RELEASE",
    "POTPIE_SENTRY_DIST",
)


@pytest.fixture(autouse=True)
def _clear_sentry_config(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg"))
    for name in _SENTRY_ENV_NAMES:
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("POTPIE_ENVIRONMENT", "test")
    monkeypatch.setattr(runtime_settings, "load_distribution_defaults", lambda: {})
    monkeypatch.setattr(shared_sentry_settings, "build_git_sha", lambda: None)


def test_telemetry_resolution_defaults_to_enabled_without_preference() -> None:
    resolution = load_telemetry_resolution()

    assert resolution.telemetry == "enabled"
    assert resolution.runtime.telemetry_disabled is False


def test_telemetry_resolution_applies_persisted_disable_as_final_cli_preference() -> (
    None
):
    save_preferences(TelemetryPreferences(enabled=False))

    resolution = load_telemetry_resolution()

    assert resolution.telemetry == "disabled"
    assert resolution.runtime.telemetry_disabled is True


def test_telemetry_resolution_env_block_wins_over_persisted_enable(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("POTPIE_TELEMETRY_DISABLED", "1")
    save_preferences(TelemetryPreferences(enabled=True))

    resolution = load_telemetry_resolution()

    assert resolution.telemetry == "blocked"
    assert resolution.runtime.telemetry_disabled is True


def test_sentry_settings_disabled_without_dsn() -> None:
    settings = load_cli_sentry_settings()

    assert settings.enabled is False
    assert settings.dsn is None
    assert settings.environment == "test"


def test_potpie_sentry_dsn_enables_sentry(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("POTPIE_SENTRY_DSN", "https://public@example.invalid/1")

    settings = load_cli_sentry_settings()

    assert settings.enabled is True
    assert settings.dsn == "https://public@example.invalid/1"


def test_sentry_settings_respects_global_kill_switch(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("POTPIE_SENTRY_DSN", "https://public@example.invalid/1")
    monkeypatch.setenv("POTPIE_TELEMETRY_DISABLED", "1")

    settings = load_cli_sentry_settings()

    assert settings.enabled is False
    assert settings.dsn == "https://public@example.invalid/1"


def test_sentry_settings_respects_persisted_telemetry_disable(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("POTPIE_SENTRY_DSN", "https://public@example.invalid/1")
    save_preferences(TelemetryPreferences(enabled=False))

    settings = load_cli_sentry_settings()

    assert settings.enabled is False
    assert settings.dsn == "https://public@example.invalid/1"


def test_sentry_settings_persisted_enable_preserves_existing_gates(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("POTPIE_SENTRY_DSN", "https://public@example.invalid/1")
    save_preferences(TelemetryPreferences(enabled=True))

    settings = load_cli_sentry_settings()

    assert settings.enabled is True


def test_sentry_settings_ignores_blank_global_kill_switch(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("POTPIE_SENTRY_DSN", "https://public@example.invalid/1")
    monkeypatch.setenv("POTPIE_TELEMETRY_DISABLED", "   ")
    monkeypatch.setenv("POTPIE_SENTRY_ENABLED", "")

    settings = load_cli_sentry_settings()

    assert settings.enabled is True
    assert settings.dsn == "https://public@example.invalid/1"


def test_potpie_environment_is_used_for_sentry_environment(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("POTPIE_ENVIRONMENT", "staging")
    monkeypatch.setenv("POTPIE_SENTRY_DSN", "https://public@example.invalid/1")

    settings = load_cli_sentry_settings()

    assert settings.environment == "staging"
    assert cli_telemetry_environment() == "staging"


def test_sentry_release_comes_from_env_or_package_version(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("POTPIE_SENTRY_DSN", "https://public@example.invalid/1")
    monkeypatch.setenv("POTPIE_SENTRY_RELEASE", "potpie-cli@test")

    settings = load_cli_sentry_settings()

    assert settings.release == "potpie-cli@test"

    monkeypatch.delenv("POTPIE_SENTRY_RELEASE")
    assert load_cli_sentry_settings().release.startswith("potpie-cli@")


def test_sentry_dist_comes_from_env_or_build_info(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("POTPIE_SENTRY_DSN", "https://public@example.invalid/1")
    monkeypatch.setattr(shared_sentry_settings, "build_git_sha", lambda: "abc123")

    settings = load_cli_sentry_settings()

    assert settings.dist == "abc123"

    monkeypatch.setenv("POTPIE_SENTRY_DIST", "explicit-dist")
    assert load_cli_sentry_settings().dist == "explicit-dist"


def test_sentry_uses_distribution_defaults_without_runtime_env(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("POTPIE_ENVIRONMENT", raising=False)
    monkeypatch.setattr(
        runtime_settings,
        "load_distribution_defaults",
        lambda: {
            "environment": "prod_oss",
            "sentry_dsn": "https://dist@example.invalid/1",
        },
    )

    settings = shared_sentry_settings.load_sentry_settings()

    assert settings.enabled is True
    assert settings.dsn == "https://dist@example.invalid/1"
    assert settings.environment == "prod_oss"


def test_sentry_runtime_env_overrides_distribution_defaults(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        runtime_settings,
        "load_distribution_defaults",
        lambda: {
            "environment": "prod_oss",
            "sentry_dsn": "https://dist@example.invalid/1",
        },
    )
    monkeypatch.setenv("POTPIE_ENVIRONMENT", "staging")
    monkeypatch.setenv("POTPIE_SENTRY_DSN", "https://runtime@example.invalid/1")

    settings = load_cli_sentry_settings()

    assert settings.enabled is True
    assert settings.dsn == "https://runtime@example.invalid/1"
    assert settings.environment == "staging"


def test_sentry_opt_outs_disable_canonical_dsn(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("POTPIE_SENTRY_DSN", "https://public@example.invalid/1")
    monkeypatch.setenv("POTPIE_SENTRY_ENABLED", "0")

    assert load_cli_sentry_settings().enabled is False

    monkeypatch.setenv("POTPIE_SENTRY_ENABLED", "1")
    monkeypatch.setenv("POTPIE_TELEMETRY_DISABLED", "1")

    assert load_cli_sentry_settings().enabled is False


def test_env_block_wins_over_persisted_enable(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("POTPIE_SENTRY_DSN", "https://public@example.invalid/1")
    monkeypatch.setenv("POTPIE_TELEMETRY_DISABLED", "1")
    save_preferences(TelemetryPreferences(enabled=True))

    settings = load_cli_sentry_settings()

    assert settings.enabled is False

from __future__ import annotations

from typer.testing import CliRunner

from potpie.cli import main as host_cli
from potpie.cli.commands import _common
from potpie.cli.telemetry.context import (
    bind_daemon_telemetry_context,
    current_telemetry_context,
)
from potpie.cli.telemetry.identity_store import load_or_create_identity


def test_cli_invocations_share_install_and_daemon_session_ids(
    monkeypatch,
    tmp_path,
) -> None:
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg"))
    monkeypatch.setenv("CONTEXT_ENGINE_HOME", str(tmp_path / "context-home"))
    monkeypatch.setenv("POTPIE_ENVIRONMENT", "staging")
    monkeypatch.delenv("POTPIE_SENTRY_DSN", raising=False)
    runner = CliRunner()

    first = runner.invoke(host_cli.app, ["--json", "daemon", "status"])
    first_ctx = current_telemetry_context()
    second = runner.invoke(host_cli.app, ["--json", "daemon", "status"])
    second_ctx = current_telemetry_context()

    # `daemon status` is a vehicle here, not the subject. No daemon runs against
    # this home, which is now a `daemon_unavailable` at EXIT_UNAVAILABLE; the
    # command still ran, which is all the telemetry assertions below need.
    assert first.exit_code == _common.EXIT_UNAVAILABLE, first.stdout
    assert second.exit_code == _common.EXIT_UNAVAILABLE, second.stdout
    assert first_ctx is not None
    assert second_ctx is not None
    assert first_ctx.anonymous_install_id == second_ctx.anonymous_install_id
    assert first_ctx.invocation_id != second_ctx.invocation_id
    assert first_ctx.daemon_session_id == second_ctx.daemon_session_id
    assert first_ctx.command == "daemon"
    assert first_ctx.subcommand is None
    assert first_ctx.environment == "staging"
    assert first_ctx.analytics_properties()["environment"] == "staging"
    assert first_ctx.output_mode == "json"
    assert (
        load_or_create_identity().anonymous_install_id == first_ctx.anonymous_install_id
    )


def test_cli_context_does_not_include_command_args(monkeypatch, tmp_path) -> None:
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg"))
    runner = CliRunner()

    result = runner.invoke(host_cli.app, ["--json", "pot", "use", "private-name"])
    ctx = current_telemetry_context()

    assert result.exit_code in {_common.EXIT_OK, _common.EXIT_VALIDATION}
    assert ctx is not None
    assert ctx.command == "pot"
    assert ctx.subcommand is None


def test_daemon_context_uses_install_id_and_ui_command(monkeypatch, tmp_path) -> None:
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "xdg"))
    ctx = bind_daemon_telemetry_context()

    assert ctx.command == "ui"
    assert ctx.subcommand is None
    assert ctx.output_mode == "ui"
    assert current_telemetry_context() is ctx
    assert load_or_create_identity().anonymous_install_id == ctx.anonymous_install_id

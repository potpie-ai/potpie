from __future__ import annotations

from dataclasses import dataclass, field
from types import SimpleNamespace

import pytest
from typer.testing import CliRunner

from potpie.cli.auth import auth_commands
from potpie.cli.commands import _common, skills as skills_commands
from potpie.cli.telemetry.onboarding_events import (
    CliSetupAnalyticsObserver,
    agent_skills_failure_kind,
    begin_setup_run,
    capture_agent_skills_install_outcome,
    capture_agent_skills_selection_outcome,
    capture_activation_command_outcome,
    capture_context_result_returned,
    capture_github_prompt_outcome,
    capture_github_prompt_shown,
    capture_setup_completed,
    capture_setup_incomplete,
    capture_setup_started,
    current_setup_run_id,
    onboarding_entrypoint,
    repo_location_kind,
)
from potpie.cli.telemetry.product_analytics import (
    ProductAnalyticsEvent,
    set_product_analytics_sink,
)
from potpie.runtime.composition import build_local_runtime
from potpie.skills.errors import InvalidSkillsInstallPathError, UnknownAgentTargetError
from potpie_context_engine.adapters.outbound.graph.backends.in_memory_backend import (
    InMemoryGraphBackend,
)
from potpie_context_engine.core.lifecycle import SetupPlan


@dataclass
class _FakeSink:
    events: list[ProductAnalyticsEvent] = field(default_factory=list)

    def capture(self, event: ProductAnalyticsEvent) -> None:
        self.events.append(event)


@pytest.fixture()
def fake_sink(monkeypatch: pytest.MonkeyPatch) -> _FakeSink:
    sink = _FakeSink()
    set_product_analytics_sink(sink)
    monkeypatch.setattr(
        "potpie.cli.telemetry.product_analytics.current_telemetry_context",
        lambda: _telemetry_context(),
    )
    return sink


def _telemetry_context():
    from potpie.cli.telemetry.context import TelemetryContext

    return TelemetryContext(
        anonymous_install_id="install_123",
        invocation_id="invoke_456",
        daemon_session_id="daemon_789",
        environment="staging",
        command="setup",
        subcommand=None,
        output_mode="json",
        cli_version="0.1.0",
        python_version="3.13.0",
        os="darwin",
        arch="arm64",
    )


def test_repo_location_kind_does_not_expose_paths() -> None:
    assert repo_location_kind(None) == "none"
    assert repo_location_kind(".") == "current_directory"
    assert repo_location_kind("/Users/dsantra/private/repo") == "explicit_path"


def test_setup_events_share_one_setup_run_id(fake_sink: _FakeSink) -> None:
    plan = SetupPlan(repo=".", agent="claude", scan=True, assume_yes=True)

    setup_run_id = begin_setup_run()
    capture_setup_started(
        plan,
        interactive=False,
        json_output=True,
        dry_run=False,
    )
    capture_setup_completed(
        plan=plan,
        ok=True,
        duration_ms=12,
        hard_failed_step=None,
        soft_warning_count=1,
    )

    assert current_setup_run_id() == setup_run_id
    assert [event.name for event in fake_sink.events] == [
        "cli_onboarding_setup_started",
        "cli_onboarding_setup_completed",
    ]
    assert fake_sink.events[0].properties["setup_run_id"] == setup_run_id
    assert fake_sink.events[0].properties["repo_location_kind"] == "current_directory"
    assert fake_sink.events[0].properties["scan_requested"] is True
    assert fake_sink.events[0].properties["dry_run"] is False
    assert fake_sink.events[1].properties["duration_ms"] == 12
    assert fake_sink.events[1].properties["dry_run"] is False
    assert "repo" not in fake_sink.events[0].properties


def test_setup_cancellation_is_an_incomplete_terminal_outcome(
    fake_sink: _FakeSink,
) -> None:
    plan = SetupPlan(repo=".", agent="claude")

    begin_setup_run()
    capture_setup_started(
        plan,
        interactive=True,
        json_output=False,
        dry_run=False,
    )
    capture_setup_incomplete(
        plan=plan,
        incomplete_kind="cancelled",
        duration_ms=17,
        failure_stage="backend.provision",
    )

    assert [event.name for event in fake_sink.events] == [
        "cli_onboarding_setup_started",
        "cli_onboarding_setup_incomplete",
    ]
    assert fake_sink.events[1].properties["duration_ms"] == 17
    assert fake_sink.events[1].properties["dry_run"] is False
    assert fake_sink.events[1].properties["incomplete_kind"] == "cancelled"
    assert fake_sink.events[1].properties["failure_stage"] == "backend.provision"
    assert fake_sink.events[1].properties["setup_run_id"] == current_setup_run_id()


def test_setup_dry_run_cancellation_preserves_dry_run_on_incomplete_event(
    fake_sink: _FakeSink,
) -> None:
    plan = SetupPlan(repo=".", agent="claude")

    begin_setup_run()
    capture_setup_started(
        plan,
        interactive=False,
        json_output=False,
        dry_run=True,
    )
    capture_setup_incomplete(
        plan=plan,
        incomplete_kind="cancelled",
        duration_ms=9,
        failure_stage="setup_execution",
        dry_run=True,
    )

    assert [event.name for event in fake_sink.events] == [
        "cli_onboarding_setup_started",
        "cli_onboarding_setup_incomplete",
    ]
    assert fake_sink.events[0].properties["dry_run"] is True
    assert fake_sink.events[1].properties["dry_run"] is True
    assert fake_sink.events[1].properties["incomplete_kind"] == "cancelled"


def test_setup_hard_failure_has_bounded_incomplete_kind(fake_sink: _FakeSink) -> None:
    capture_setup_completed(
        plan=SetupPlan(),
        ok=False,
        duration_ms=23,
        hard_failed_step="config",
        soft_warning_count=0,
    )

    assert fake_sink.events[0].name == "cli_onboarding_setup_incomplete"
    assert fake_sink.events[0].properties["incomplete_kind"] == "hard_failure"
    assert fake_sink.events[0].properties["failure_stage"] == "config"


def test_setup_dry_run_is_explicit_on_started_event(fake_sink: _FakeSink) -> None:
    capture_setup_started(
        SetupPlan(),
        interactive=False,
        json_output=False,
        dry_run=True,
    )

    assert fake_sink.events[0].properties["dry_run"] is True


@pytest.mark.parametrize(
    ("interactive", "json_output"),
    [
        (True, False),
        (False, False),
        (False, True),
    ],
    ids=["interactive", "plain", "json"],
)
def test_setup_started_preserves_output_mode_dimensions(
    fake_sink: _FakeSink,
    *,
    interactive: bool,
    json_output: bool,
) -> None:
    capture_setup_started(
        SetupPlan(),
        interactive=interactive,
        json_output=json_output,
    )

    assert fake_sink.events[0].properties["interactive"] is interactive
    assert fake_sink.events[0].properties["json_output"] is json_output


def test_setup_observer_emits_step_timing(
    fake_sink: _FakeSink, tmp_path, monkeypatch
) -> None:
    monkeypatch.setenv("CONTEXT_ENGINE_HOME", str(tmp_path))
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    runtime = build_local_runtime(backend=InMemoryGraphBackend())
    runtime.root.setup.set_observer(CliSetupAnalyticsObserver())
    begin_setup_run()

    report = runtime.root.setup.run(
        SetupPlan(repo=".", agent="claude", defer_default_pot=True)
    )

    assert report.ok is True
    names = [event.name for event in fake_sink.events]
    assert "cli_onboarding_setup_step_started" in names
    assert "cli_onboarding_setup_step_completed" in names
    source_events = [
        event
        for event in fake_sink.events
        if event.properties.get("step") == "source"
        and event.name == "cli_onboarding_setup_step_completed"
    ]
    assert source_events[0].properties["step_state"] == "skipped"
    duration_ms = source_events[0].properties["duration_ms"]
    assert isinstance(duration_ms, int)
    assert duration_ms >= 0


def test_github_prompt_events_record_prompt_outcome(fake_sink: _FakeSink) -> None:
    begin_setup_run()

    capture_github_prompt_shown(default_answer=True)
    capture_github_prompt_outcome("accepted", duration_ms=25)

    assert [event.name for event in fake_sink.events] == [
        "cli_onboarding_github_prompt_shown",
        "cli_onboarding_github_prompt_accepted",
    ]
    assert fake_sink.events[1].properties["duration_ms"] == 25


def test_github_prompt_unknown_outcome_falls_back_to_aborted(
    fake_sink: _FakeSink,
) -> None:
    begin_setup_run()

    capture_github_prompt_outcome("unexpected", duration_ms=25)

    assert [event.name for event in fake_sink.events] == [
        "cli_onboarding_github_prompt_aborted"
    ]
    assert fake_sink.events[0].properties["duration_ms"] == 25


def test_activation_events_have_canonical_repeatable_names(
    fake_sink: _FakeSink,
) -> None:
    begin_setup_run()

    capture_activation_command_outcome(
        command="resolve",
        outcome="succeeded",
        result_kind="context_result",
        duration_ms=17,
    )
    capture_context_result_returned(
        command="resolve",
        item_count=3,
        confidence="high",
    )

    assert [event.name for event in fake_sink.events] == [
        "cli_onboarding_activation_command_outcome",
        "cli_onboarding_context_result_returned",
    ]
    assert fake_sink.events[0].properties["command"] == "resolve"
    assert fake_sink.events[0].properties["outcome"] == "succeeded"
    assert fake_sink.events[0].properties["duration_ms"] == 17
    assert fake_sink.events[1].properties["item_count"] == 3
    assert fake_sink.events[1].properties["result_kind"] == "non_empty"
    assert fake_sink.events[1].properties["confidence"] == "high"


def test_empty_context_result_and_unknown_confidence_are_bounded(
    fake_sink: _FakeSink,
) -> None:
    capture_context_result_returned(
        command="search",
        item_count=0,
        confidence="unbounded-value",
    )

    assert fake_sink.events[0].properties["result_kind"] == "empty"
    assert fake_sink.events[0].properties["item_count"] == 0
    assert fake_sink.events[0].properties["confidence"] == "unknown"


def test_activation_failure_category_is_bounded(fake_sink: _FakeSink) -> None:
    capture_activation_command_outcome(
        command="status",
        outcome="expected_failed",
        result_kind="status_result",
        duration_ms=3,
        failure_category="private-dynamic-error",
    )

    assert fake_sink.events[0].properties["failure_category"] == "other_expected"


@pytest.mark.parametrize(
    ("exc", "expected"),
    [
        (UnknownAgentTargetError("agent name changed"), "invalid_agent"),
        (
            InvalidSkillsInstallPathError("path validation text changed"),
            "filesystem",
        ),
        (ValueError("No install target registered for agent 'other'"), "unexpected"),
        (
            ValueError("Expected a directory path, got file: /private/repo"),
            "unexpected",
        ),
        (ValueError("other validation failure"), "unexpected"),
        (PermissionError("denied"), "permission_denied"),
        (OSError("disk unavailable"), "filesystem"),
        (RuntimeError("unexpected"), "unexpected"),
    ],
)
def test_agent_skills_failure_kind_is_bounded(
    exc: BaseException, expected: str
) -> None:
    assert agent_skills_failure_kind(exc) == expected


@dataclass
class _InstallSkills:
    results: list[object] = field(default_factory=list)
    error: Exception | None = None

    def install(self, **kwargs: object) -> object:
        del kwargs
        if self.error is not None:
            raise self.error
        return self.results.pop(0)


def test_direct_skills_install_emits_one_canonical_outcome_per_command(
    fake_sink: _FakeSink,
) -> None:
    fake_skills = _InstallSkills(
        results=[
            SimpleNamespace(agent="codex", changed=("potpie-cli",), metadata={}),
            SimpleNamespace(agent="codex", changed=(), metadata={}),
        ]
    )
    _common.set_runtime(SimpleNamespace(skills=fake_skills))

    runner = CliRunner()
    first = runner.invoke(skills_commands.skills_app, ["install", "--agent", "CoDeX"])
    second = runner.invoke(skills_commands.skills_app, ["install", "--agent", "codex"])

    assert first.exit_code == 0, first.output
    assert second.exit_code == 0, second.output
    outcomes = [
        event
        for event in fake_sink.events
        if event.name == "cli_onboarding_agent_skills_install_outcome"
    ]
    assert len(outcomes) == 2
    assert [event.properties["outcome"] for event in outcomes] == [
        "installed",
        "already_installed",
    ]
    for event in outcomes:
        assert event.properties["agent"] == "codex"
        assert event.properties["entrypoint"] == "direct_command"
        assert event.properties["scope"] == "global"
        assert "failure_kind" not in event.properties
        assert "skill_id" not in event.properties


def test_direct_skills_install_captures_bounded_failure_outcome(
    fake_sink: _FakeSink,
) -> None:
    _common.set_runtime(
        SimpleNamespace(skills=_InstallSkills(error=PermissionError("private path")))
    )

    result = CliRunner().invoke(
        skills_commands.skills_app, ["install", "--agent", "codex"]
    )

    assert result.exit_code != 0
    assert [event.name for event in fake_sink.events] == [
        "cli_onboarding_agent_skills_install_outcome",
    ]
    outcome = fake_sink.events[0]
    assert outcome.properties["outcome"] == "failed"
    assert outcome.properties["failure_kind"] == "permission_denied"
    assert "private path" not in outcome.properties.values()


def test_direct_skills_install_captures_cancelled_outcome(
    fake_sink: _FakeSink,
) -> None:
    _common.set_runtime(
        SimpleNamespace(skills=_InstallSkills(error=KeyboardInterrupt()))
    )

    result = CliRunner().invoke(
        skills_commands.skills_app, ["install", "--agent", "codex"]
    )

    assert result.exit_code == 130
    assert [event.name for event in fake_sink.events] == [
        "cli_onboarding_agent_skills_install_outcome",
    ]
    outcome = fake_sink.events[0]
    assert outcome.properties["outcome"] == "cancelled"
    assert "failure_kind" not in outcome.properties


def test_direct_skills_install_skips_canonical_events_for_non_activation_agents(
    fake_sink: _FakeSink,
) -> None:
    _common.set_runtime(
        SimpleNamespace(
            skills=_InstallSkills(
                results=[
                    SimpleNamespace(
                        agent="default", changed=("AGENTS.md",), metadata={}
                    )
                ]
            )
        )
    )

    result = CliRunner().invoke(
        skills_commands.skills_app, ["install", "--agent", "default"]
    )

    assert result.exit_code == 0, result.output
    assert [
        event
        for event in fake_sink.events
        if event.name == "cli_onboarding_agent_skills_install_outcome"
    ] == []
    assert [event.name for event in fake_sink.events] == [
        "cli_usage_command_succeeded",
    ]


def test_direct_skills_install_drops_canonical_events_for_invalid_agent_failure(
    fake_sink: _FakeSink,
) -> None:
    _common.set_runtime(
        SimpleNamespace(
            skills=_InstallSkills(
                error=UnknownAgentTargetError("install target is unavailable")
            )
        )
    )

    result = CliRunner().invoke(
        skills_commands.skills_app, ["install", "--agent", "default"]
    )

    assert result.exit_code != 0
    assert fake_sink.events == []


def test_direct_skills_install_drops_canonical_events_for_invalid_scope(
    fake_sink: _FakeSink,
) -> None:
    _common.set_runtime(
        SimpleNamespace(
            skills=_InstallSkills(
                error=ValueError("scope must be 'global' or 'project'")
            )
        )
    )

    result = CliRunner().invoke(
        skills_commands.skills_app,
        ["install", "--agent", "cursor", "--scope", "banana"],
    )

    assert result.exit_code != 0
    assert fake_sink.events == []


@pytest.mark.parametrize(
    ("outcome", "failure_kind"),
    [
        ("installed", None),
        ("failed", "filesystem"),
    ],
)
def test_agent_skills_events_drop_noncanonical_scope(
    fake_sink: _FakeSink,
    outcome: str,
    failure_kind: str | None,
) -> None:
    capture_agent_skills_install_outcome(
        agent="codex",
        entrypoint="direct_command",
        scope="/private/repo",
        outcome=outcome,
        duration_ms=1,
        failure_kind=failure_kind,
    )

    assert fake_sink.events == []


def test_agent_skills_events_drop_invalid_install_outcome(
    fake_sink: _FakeSink,
) -> None:
    capture_agent_skills_install_outcome(
        agent="codex",
        entrypoint="direct_command",
        scope="global",
        outcome="PermissionError: private path",
        duration_ms=1,
    )

    assert fake_sink.events == []


def test_agent_skills_events_drop_invalid_failure_kind(
    fake_sink: _FakeSink,
) -> None:
    capture_agent_skills_install_outcome(
        agent="codex",
        entrypoint="direct_command",
        scope="global",
        outcome="failed",
        duration_ms=1,
        failure_kind="PermissionError: /private/repo",
    )

    assert fake_sink.events == []


def test_agent_skills_events_drop_invalid_selection_outcome(
    fake_sink: _FakeSink,
) -> None:
    capture_agent_skills_selection_outcome(
        selection_outcome="user typed a prompt",
        selected_agents=("claude",),
        duration_ms=12,
    )

    assert fake_sink.events == []


def test_agent_skills_selection_keeps_only_canonical_agents(
    fake_sink: _FakeSink,
) -> None:
    capture_agent_skills_selection_outcome(
        selection_outcome="selected",
        selected_agents=("claude", "default", "codex"),
        duration_ms=12,
    )

    outcome = fake_sink.events[0]
    assert outcome.name == "cli_onboarding_agent_skills_selection_outcome"
    assert outcome.properties["selected_agents"] == ("claude", "codex")
    assert outcome.properties["selected_agent_count"] == 2


def test_direct_linear_login_records_integration_funnel(
    fake_sink: _FakeSink,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[tuple[bool, bool]] = []

    def _fake_linear_login(*, force: bool = False, add: bool = False) -> None:
        calls.append((force, add))

    monkeypatch.setattr(auth_commands, "_run_linear_oauth_flow", _fake_linear_login)

    auth_commands.linear_login(force=True, add=True)

    assert calls == [(True, True)]
    assert [event.name for event in fake_sink.events] == [
        "cli_onboarding_integration_auth_started",
        "cli_onboarding_integration_auth_completed",
    ]
    assert fake_sink.events[0].properties["provider"] == "linear"
    assert fake_sink.events[0].properties["entrypoint"] == "direct_integration_auth"


def test_integration_login_records_unexpected_failure(
    fake_sink: _FakeSink,
) -> None:
    class _IntegrationFailure(RuntimeError):
        pass

    def _run() -> None:
        raise _IntegrationFailure("boom")

    with pytest.raises(_IntegrationFailure):
        auth_commands._run_tracked_integration_login(
            "linear",
            entrypoint="direct_integration_auth",
            runner=_run,
        )

    assert [event.name for event in fake_sink.events] == [
        "cli_onboarding_integration_auth_started",
        "cli_onboarding_integration_auth_failed",
    ]
    assert fake_sink.events[1].properties["provider"] == "linear"
    assert fake_sink.events[1].properties["failure_kind"] == "_IntegrationFailure"


def test_setup_picker_login_preserves_entrypoint(
    fake_sink: _FakeSink,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        auth_commands,
        "_run_linear_oauth_flow",
        lambda *, force=False, add=False: None,
    )

    with onboarding_entrypoint("post_setup_integration_picker"):
        auth_commands.run_integration_login("linear")

    assert fake_sink.events[0].properties["provider"] == "linear"
    assert (
        fake_sink.events[0].properties["entrypoint"] == "post_setup_integration_picker"
    )


def test_setup_atlassian_login_runs_shared_jira_flow(
    fake_sink: _FakeSink,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, object]] = []

    def _fake_atlassian_login(product: str, **kwargs: object) -> None:
        calls.append({"product": product, **kwargs})

    monkeypatch.setattr(
        auth_commands, "ensure_runtime_environment_loaded", lambda: None
    )
    monkeypatch.setattr(auth_commands, "_flags", lambda: (False, False))
    monkeypatch.setattr(
        auth_commands,
        "run_atlassian_api_token_auth",
        _fake_atlassian_login,
    )

    with onboarding_entrypoint("post_setup_integration_picker"):
        auth_commands.run_integration_login("atlassian", force=True)

    assert calls == [
        {"product": "atlassian", "force": True, "as_json": False, "verbose": False}
    ]
    assert fake_sink.events[0].properties["provider"] == "atlassian"
    assert (
        fake_sink.events[0].properties["entrypoint"] == "post_setup_integration_picker"
    )


def test_direct_atlassian_login_records_funnel_without_credentials(
    fake_sink: _FakeSink,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, object]] = []

    def _fake_atlassian_login(product: str, **kwargs: object) -> None:
        calls.append({"product": product, **kwargs})

    monkeypatch.setattr(
        auth_commands, "ensure_runtime_environment_loaded", lambda: None
    )
    monkeypatch.setattr(
        auth_commands,
        "run_atlassian_api_token_auth",
        _fake_atlassian_login,
    )

    auth_commands.jira_login(
        force=True,
        email="developer@example.com",
        api_token="secret-token",
        site_subdomain="potpie",
    )

    assert calls[0]["product"] == "jira"
    assert [event.name for event in fake_sink.events] == [
        "cli_onboarding_integration_auth_started",
        "cli_onboarding_integration_auth_completed",
    ]
    for event in fake_sink.events:
        assert event.properties["provider"] == "jira"
        assert "email" not in event.properties
        assert "api_token" not in event.properties
        assert "site_subdomain" not in event.properties

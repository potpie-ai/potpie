"""Unit tests for the local graph-explorer UI router helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from typing import Any

import pytest
from fastapi.testclient import TestClient

from potpie.cli.telemetry import product_analytics
from potpie.cli.telemetry.context import TelemetryContext
from potpie.daemon.http.ui import build_ui_app
from potpie.daemon.http.ui.router import (
    _caption,
    _node_type,
    _parse_scope,
    _slice_to_graph,
)
from potpie_context_engine.core.ports.graph.inspection import (
    GraphEdge,
    GraphNode,
    GraphSlice,
)

if TYPE_CHECKING:
    from potpie.cli.telemetry.product_analytics import ProductAnalyticsEvent

_TOKEN = "router-test-daemon-token"  # noqa: S105 - non-secret test fixture


def _client(*, pots: Any, graph: Any, backend: Any) -> TestClient:
    """The explorer app as the daemon builds it, called with the daemon token."""
    app = build_ui_app(pots=pots, graph=graph, backend=backend, bearer_token=_TOKEN)
    return TestClient(
        app,
        base_url="http://127.0.0.1:8765",
        headers={"Authorization": f"Bearer {_TOKEN}"},
    )


def test_node_type_prefers_canonical_key_prefix_over_stray_label() -> None:
    # An Activity node that also accumulated a Dependency label must still
    # resolve to Activity (the key prefix is authoritative).
    assert (
        _node_type("activity:github:pr-848", ["Entity", "Dependency", "Activity"])
        == "Activity"
    )
    assert _node_type("activity:github:pr-848", ["Entity", "Dependency"]) == "Activity"
    assert _node_type("repo:github.com/o/r", ["Entity", "Repository"]) == "Repository"


def test_node_type_falls_back_to_label_then_entity() -> None:
    assert _node_type("weird:thing", ["Entity", "Custom"]) == "Custom"
    assert _node_type("weird:thing", ["Entity"]) == "Entity"


def test_caption_prefers_summary_then_title_name_then_key_tail() -> None:
    assert (
        _caption("service:web", {"summary": "Web frontend service.", "name": "web"})
        == "Web frontend service."
    )
    assert _caption("activity:github:pr-1", {"title": "Add X"}) == "Add X"
    assert _caption("person:jane-doe", {"name": "Jane Doe"}) == "Jane Doe"
    assert _caption("repo:github.com/o/r", {}) == "github.com/o/r"


def test_caption_uses_description_for_old_nodes_without_summary() -> None:
    assert (
        _caption(
            "service:web", {"description": "Web frontend service for browser clients."}
        )
        == "Web frontend service for browser clients."
    )


def test_slice_to_graph_shape() -> None:
    sl = GraphSlice(
        pot_id="p",
        nodes=(
            GraphNode(
                key="repo:x", labels=("Entity", "Repository"), properties={"name": "x"}
            ),
            GraphNode(key="person:y", labels=("Entity", "Person"), properties={}),
        ),
        edges=(GraphEdge(predicate="PERFORMED", from_key="person:y", to_key="repo:x"),),
        truncated=False,
    )
    g = _slice_to_graph(sl)
    assert [n["type"] for n in g["nodes"]] == ["Repository", "Person"]
    assert g["nodes"][0]["caption"] == "x"
    assert g["nodes"][0]["summary"] == "x"
    assert g["edges"][0] == {
        "id": "person:y|PERFORMED|repo:x",
        "source": "person:y",
        "target": "repo:x",
        "predicate": "PERFORMED",
    }
    assert g["truncated"] is False


def test_parallel_claims_get_distinct_edge_ids() -> None:
    """The explorer selects and diffs edges by id; two claims on the same
    endpoints and predicate must not collapse into one."""
    edges = (
        GraphEdge(
            predicate="DEPENDS_ON",
            from_key="service:a",
            to_key="service:b",
            properties={"claim_key": "claim:one"},
        ),
        GraphEdge(
            predicate="DEPENDS_ON",
            from_key="service:a",
            to_key="service:b",
            properties={"claim_key": "claim:two"},
        ),
        GraphEdge(
            predicate="DEPENDS_ON",
            from_key="service:a",
            to_key="service:b",
            properties={"record_id": "record-3", "claim_key": "claim:three"},
        ),
    )
    sl = GraphSlice(pot_id="p", nodes=(), edges=edges, truncated=False)

    ids = [edge["id"] for edge in _slice_to_graph(sl)["edges"]]

    assert ids == [
        "service:a|DEPENDS_ON|service:b|claim:one",
        "service:a|DEPENDS_ON|service:b|claim:two",
        "record-3",
    ]


def test_parse_scope() -> None:
    assert _parse_scope("repo:o/r,path:src/a.py") == {"repo": "o/r", "path": "src/a.py"}
    assert _parse_scope(None) == {}
    assert _parse_scope("bad,key:val") == {"key": "val"}


def test_pots_api_includes_counts_for_selector() -> None:
    class Pot:
        def __init__(self, pot_id, name, active=False):
            self.pot_id = pot_id
            self.name = name
            self.active = active

    class Pots:
        def __init__(self):
            self.p1 = Pot("p1", "empty", True)
            self.p2 = Pot("p2", "review")

        def list_pots(self):
            return [self.p1, self.p2]

        def active_pot(self):
            return self.p1

        def list_sources(self, *, pot_id):
            return [object()] if pot_id == "p2" else []

    class Status:
        def __init__(self, counts):
            self.counts = counts

    class Graph:
        def data_plane_status(self, pot_id):
            return Status(
                {"claims": 82, "entities": 46} if pot_id == "p2" else {"claims": 0}
            )

    client = _client(pots=Pots(), graph=Graph(), backend=object())

    response = client.get("/ui/api/pots")

    assert response.status_code == 200
    body = response.json()
    assert body["pots"][0]["counts"]["claims"] == 0
    assert body["pots"][1]["source_count"] == 1
    assert body["pots"][1]["counts"] == {"claims": 82, "entities": 46}


def test_ui_session_beacon_records_usage_without_sensitive_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class _Sink:
        events: list[ProductAnalyticsEvent] = []

        def capture(self, event: ProductAnalyticsEvent) -> None:
            self.events.append(event)

    sink = _Sink()
    monkeypatch.setattr(product_analytics, "_sink", sink)
    monkeypatch.setattr(
        "potpie.cli.telemetry.product_analytics.current_telemetry_context",
        lambda: TelemetryContext(
            anonymous_install_id="install_123",
            invocation_id="invoke_456",
            daemon_session_id="daemon_789",
            environment="staging",
            command="ui",
            subcommand=None,
            output_mode="ui",
            cli_version="0.1.0",
            python_version="3.13.0",
            os="darwin",
            arch="arm64",
        ),
    )
    client = _client(pots=object(), graph=object(), backend=object())
    response = client.post(
        "/ui/api/telemetry/session",
        json={
            "had_graph": True,
            "pot_id": "secret-pot",
            "query": "private source",
            "name": "My Repo",
        },
    )
    assert response.status_code == 200
    assert response.json() == {"ok": True}
    assert len(sink.events) == 1
    event = sink.events[0]
    assert event.name == "cli_usage_command_succeeded"
    assert event.properties["command"] == "ui"
    assert event.properties["result_kind"] == "ui_session"
    assert event.properties["feature"] == "ui"
    assert event.properties["had_graph"] is True
    dumped = repr(event.properties)
    assert "secret-pot" not in dumped
    assert "private source" not in dumped
    assert "My Repo" not in dumped


def test_pots_list_does_not_record_ui_session(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class _Sink:
        events: list[ProductAnalyticsEvent] = []

        def capture(self, event: ProductAnalyticsEvent) -> None:
            self.events.append(event)

    class Pot:
        def __init__(self, pot_id: str, name: str, active: bool = False) -> None:
            self.pot_id = pot_id
            self.name = name
            self.active = active

    class Pots:
        def list_pots(self):
            return [Pot("p1", "empty", True)]

        def active_pot(self):
            return Pot("p1", "empty", True)

        def list_sources(self, *, pot_id):
            return []

    class Graph:
        def data_plane_status(self, pot_id):
            return type("Status", (), {"counts": {}})()

    sink = _Sink()
    monkeypatch.setattr(product_analytics, "_sink", sink)
    client = _client(pots=Pots(), graph=Graph(), backend=object())
    response = client.get("/ui/api/pots")
    assert response.status_code == 200
    assert sink.events == []


def test_ui_session_beacon_succeeds_when_analytics_is_noop() -> None:
    client = _client(pots=object(), graph=object(), backend=object())
    response = client.post("/ui/api/telemetry/session")
    assert response.status_code == 200
    assert response.json() == {"ok": True}

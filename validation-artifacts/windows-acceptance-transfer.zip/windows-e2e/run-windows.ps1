param(
    [string]$QdrantUrl = '',
    [switch]$StartLocalQdrant,
    [string]$Python = 'python',
    [string]$Results = ''
)

$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') {
    throw 'This runner requires Windows; it does not emulate Windows on another OS.'
}
$RunnerArguments = @(
    '-I', (Join-Path $PSScriptRoot 'run_windows_install.py')
)
if ($StartLocalQdrant) { $RunnerArguments += '--start-local-qdrant' }
if ($QdrantUrl) { $RunnerArguments += @('--qdrant-url', $QdrantUrl) }
if ($Results) { $RunnerArguments += @('--results', $Results) }
& $Python @RunnerArguments
if ($LASTEXITCODE -ne 0) {
    throw "Windows installation or acceptance failed (exit $LASTEXITCODE). See the printed results directory."
}
